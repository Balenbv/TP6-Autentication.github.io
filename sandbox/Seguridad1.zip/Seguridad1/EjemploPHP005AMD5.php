<html>
<head>
 <title>Problema</title>
 </head>

 <body>
 <form action="EjemploPHP005BMD5.php" method="post" enctype="multipart/form-data">
 Ingrese la 'clave'
 <input type="text" name="clave"><br>

 <input type="submit" value="Enviar">

 </form>
</body>
</html>