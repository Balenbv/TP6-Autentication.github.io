<?php
$value = 'algun valor';
/**
se setea el valor de la cookie TestCookie con el valor 'algun valor'
*/
setcookie("TestCookie", $value);
?>
