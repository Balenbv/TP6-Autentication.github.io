<pre>
<?php
session_start();
/**
imprime los valores de la sesion
*/
print_r($_SESSION);
?> 
</pre>
