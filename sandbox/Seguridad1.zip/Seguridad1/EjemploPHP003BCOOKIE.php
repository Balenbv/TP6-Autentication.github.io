<pre>
<?php
/**
:TODO Mostrar como se ve la cookie desde el cliente
*/
echo $_COOKIE["TestCookie"];


print_r($_COOKIE);
?> 
</pre>
