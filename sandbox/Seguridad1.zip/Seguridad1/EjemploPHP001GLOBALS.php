<pre>
<?php
/**
imprime todas las variables que estan siendo utilizadas
*/
    print_r($GLOBALS);
?>
</pre>